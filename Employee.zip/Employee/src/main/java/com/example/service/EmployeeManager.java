package com.example.service;

import java.util.List;
import java.util.Optional;
import com.example.model.Employee;
import com.example.Employees;
import org.springframework.stereotype.Service;
@Service
public class EmployeeManager {
    private Employees employees = new Employees();

    public List<Employee> getAllEmployees() {
        return employees.getAllEmployees();
    }

    public Optional<Employee> getEmployeeById(String id) {
    	
    	return employees.getAllEmployees().stream()
                .filter(emp -> emp.getEmployee_id().equals(id))
                .findFirst();
    }
    public void addEmployee(Employee employee) {
        employees.getAllEmployees().add(employee);
        System.out.println("Employee added: " + employee.getFirst_name()); 
    }
    public boolean updateEmployee(String id, Employee updatedEmployee) {
        Optional<Employee> employeeOptional = getEmployeeById(id);
        if (employeeOptional.isPresent()) {
            Employee employee = employeeOptional.get();
            employee.setFirst_name(updatedEmployee.getFirst_name());
            employee.setLast_name(updatedEmployee.getLast_name());
            employee.setEmail(updatedEmployee.getEmail());
            employee.setTitle(updatedEmployee.getTitle());
            return true;
        }
        return false;
    }

	/*
	 * public boolean deleteEmployee(String id) {
	 * 
	 * return employees.getAllEmployees().removeIf(emp ->
	 * emp.getEmployee_id().equals(id)); }
	 */
    public boolean deleteEmployee(String id) {
        return employees.getAllEmployees().removeIf(emp -> emp.getEmployee_id().equals(id));
    }


}
