package com.example.controller;

  import java.util.Optional;
  import com.example.model.Employee;
  import com.example.Employees;
  import com.example.service.EmployeeManager;
  import org.springframework.http.ResponseEntity; import
  org.springframework.http.HttpStatus; import
  org.springframework.web.bind.annotation.GetMapping; import
  org.springframework.web.bind.annotation.PathVariable; import
  org.springframework.web.bind.annotation.PostMapping; import
  org.springframework.web.bind.annotation.PutMapping; import
  org.springframework.web.bind.annotation.DeleteMapping; import
  org.springframework.web.bind.annotation.CrossOrigin; import
  org.springframework.web.bind.annotation.RequestBody; import
  org.springframework.web.bind.annotation.RestController;
  import org.springframework.beans.factory.annotation.Autowired;

  
  import java.util.List;
  
  @CrossOrigin(origins = "*")
  
  @RestController 
  public class EmployeeController { 
	  
  @Autowired
  private EmployeeManager employeeManager;
	  
  private Employees employees = new Employees();
  //EmployeeManager employeeManager = new EmployeeManager();
  
  @GetMapping("/employees") 
  public List<Employee> getEmployees() { 
	  return employeeManager.getAllEmployees(); }
  
  @GetMapping("/employees/{id}") 
  public ResponseEntity<Employee> getEmployeeById(@PathVariable String id) {  
  Optional<Employee> employee = employeeManager.getEmployeeById(id); 
  if (employee.isPresent()) { 
	  return new ResponseEntity<>(employee.get(), HttpStatus.OK); } 
  else { 
	  return new ResponseEntity<>(HttpStatus.NOT_FOUND); } }
  
  @PostMapping("/employees") 
  public Employee addEmployee(@RequestBody Employee newEmployee) {   
  employeeManager.addEmployee(newEmployee); 
  	return newEmployee; 
  } 
  // PUT:
  //Update an existing employee
  
  @PutMapping("/employees/{id}") public String updateEmployee(@PathVariable
  String id, @RequestBody Employee updatedEmployee) {  if
  (employeeManager.updateEmployee(id, updatedEmployee)) { return
  "Employee updated successfully"; } else { return "Employee not found"; } }
  
  // DELETE: Remove an employee by ID
  
	/*
	 * @DeleteMapping("/employees/{id}") public ResponseEntity<String>
	 * deleteEmployee(@PathVariable String id) { try { Long employeeId =
	 * Long.parseLong(id); // Convert String to Long boolean isDeleted =
	 * employeeManager.deleteEmployee(employeeId); if (isDeleted) { return
	 * ResponseEntity.ok("Employee deleted successfully"); } else { return
	 * ResponseEntity.status(HttpStatus.NOT_FOUND).body("Employee not found"); } }
	 * catch (NumberFormatException e) { return
	 * ResponseEntity.badRequest().body("Invalid employee ID format"); } }
	 */
  @DeleteMapping("/employees/{id}")
  public String deleteEmployee(@PathVariable String id) {
	  employeeManager.deleteEmployee(id);
      if (!employeeManager.deleteEmployee(id)) {
          return "Employee not found";
      }
      else {
    	  return
    			  "Employee deleted successfully";
      }
  }

  }
 


