package com.example;

import java.util.ArrayList;
import java.util.List;
import com.example.model.Employee;
public class Employees {
    private List<Employee> employeeList;

    public Employees() {
        employeeList = new ArrayList<>();
        employeeList.add(new Employee("1", "John", "Doe", "john.doe@example.com", "Software Engineer"));
        employeeList.add(new Employee("2", "Jane", "Smith", "jane.smith@example.com", "Project Manager"));
    }

    public List<Employee> getAllEmployees() {
        return employeeList;
    }
}
