const API_URL = 'http://localhost:8080/employees';

// Fetch and display all employees
if (window.location.pathname.endsWith('employees-list.html')) {
    fetch(API_URL)
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector('#employees-table tbody');
            tableBody.innerHTML = '';
            data.forEach(employee => {
                tableBody.innerHTML += `
                    <tr>
                        <td>${employee.employee_id}</td>
                        <td>${employee.first_name}</td>
                        <td>${employee.last_name}</td>
                        <td>${employee.email}</td>
                        <td>${employee.title}</td>
                        <td>
                            <button class="btn btn-danger" onclick="deleteEmployee(${employee.employee_id})">Delete</button>
                        </td>
                    </tr>
                `;
            });
        });
}

// Add a new employee
if (window.location.pathname.endsWith('add-employee.html')) {
    document.getElementById('add-employee-form').addEventListener('submit', function (event) {
        event.preventDefault();

        const employee = {
			employee_id: document.getElementById('employee_id').value,
            first_name: document.getElementById('first_name').value,
            last_name: document.getElementById('last_name').value,
            email: document.getElementById('email').value,
            title: document.getElementById('title').value
        };

        fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(employee),
        })
            .then(response => response.json())
            .then(data => {
                alert('Employee added successfully!');
                window.location.href = 'employees-list.html';
            });
            document.getElementById('add-employee-form').reset();
    });
}

// Delete an employee
function deleteEmployee(id) {
    if (confirm('Are you sure you want to delete this employee?')) {
        fetch(`${API_URL}/${id}`, {
            method: 'DELETE',
        })
            .then(response => response.text())
            .then(data => {
                alert('Employee deleted successfully!');
                window.location.reload();
            });
    }
}
